#ifndef _CORE_H_INCLUDE
#define _CORE_H_INCLUDE

#include <gb/gb.h>

void core_reset() BANKED;
void core_run() BANKED;

#endif