#ifndef SPRITESHEET_9_H
#define SPRITESHEET_9_H

// SpriteSheet: 9

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_9)
extern const struct spritesheet_t spritesheet_9;

#endif
