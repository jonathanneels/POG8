#ifndef TILESET_11_H
#define TILESET_11_H

// Tileset: 11

#include "gbs_types.h"

BANKREF_EXTERN(tileset_11)
extern const struct tileset_t tileset_11;

#endif
