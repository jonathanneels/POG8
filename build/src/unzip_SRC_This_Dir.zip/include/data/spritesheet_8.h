#ifndef SPRITESHEET_8_H
#define SPRITESHEET_8_H

// SpriteSheet: 8

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_8)
extern const struct spritesheet_t spritesheet_8;

#endif
