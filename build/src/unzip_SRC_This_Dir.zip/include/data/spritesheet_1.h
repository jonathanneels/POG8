#ifndef SPRITESHEET_1_H
#define SPRITESHEET_1_H

// SpriteSheet: 1

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_1)
extern const struct spritesheet_t spritesheet_1;

#endif
