#ifndef SCRIPT_INPUT_23_H
#define SCRIPT_INPUT_23_H

// Script script_input_23

#include "gbs_types.h"

BANKREF_EXTERN(script_input_23)
extern const unsigned char script_input_23[];

#endif
