#ifndef TILESET_1_H
#define TILESET_1_H

// Tileset: 1

#include "gbs_types.h"

BANKREF_EXTERN(tileset_1)
extern const struct tileset_t tileset_1;

#endif
