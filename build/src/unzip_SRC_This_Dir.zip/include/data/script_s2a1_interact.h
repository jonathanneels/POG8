#ifndef SCRIPT_S2A1_INTERACT_H
#define SCRIPT_S2A1_INTERACT_H

// Script script_s2a1_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s2a1_interact)
extern const unsigned char script_s2a1_interact[];

#endif
