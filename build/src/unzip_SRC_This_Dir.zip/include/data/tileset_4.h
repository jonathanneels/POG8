#ifndef TILESET_4_H
#define TILESET_4_H

// Tileset: 4

#include "gbs_types.h"

BANKREF_EXTERN(tileset_4)
extern const struct tileset_t tileset_4;

#endif
