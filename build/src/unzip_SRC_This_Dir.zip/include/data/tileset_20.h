#ifndef TILESET_20_H
#define TILESET_20_H

// Tileset: 20

#include "gbs_types.h"

BANKREF_EXTERN(tileset_20)
extern const struct tileset_t tileset_20;

#endif
