#ifndef BACKGROUND_3_H
#define BACKGROUND_3_H

// Background: 3

#include "gbs_types.h"

BANKREF_EXTERN(background_3)
extern const struct background_t background_3;

#endif
