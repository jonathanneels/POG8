#ifndef TILESET_13_H
#define TILESET_13_H

// Tileset: 13

#include "gbs_types.h"

BANKREF_EXTERN(tileset_13)
extern const struct tileset_t tileset_13;

#endif
