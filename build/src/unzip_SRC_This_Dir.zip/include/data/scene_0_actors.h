#ifndef SCENE_0_ACTORS_H
#define SCENE_0_ACTORS_H

// Scene: sceneInteraction
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_0_actors)
extern const struct actor_t scene_0_actors[];

#endif
