#ifndef TILESET_14_H
#define TILESET_14_H

// Tileset: 14

#include "gbs_types.h"

BANKREF_EXTERN(tileset_14)
extern const struct tileset_t tileset_14;

#endif
