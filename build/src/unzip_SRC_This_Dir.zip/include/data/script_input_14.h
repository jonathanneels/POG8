#ifndef SCRIPT_INPUT_14_H
#define SCRIPT_INPUT_14_H

// Script script_input_14

#include "gbs_types.h"

BANKREF_EXTERN(script_input_14)
extern const unsigned char script_input_14[];

#endif
