#ifndef TILESET_8_H
#define TILESET_8_H

// Tileset: 8

#include "gbs_types.h"

BANKREF_EXTERN(tileset_8)
extern const struct tileset_t tileset_8;

#endif
