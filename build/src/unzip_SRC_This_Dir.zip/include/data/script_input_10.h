#ifndef SCRIPT_INPUT_10_H
#define SCRIPT_INPUT_10_H

// Script script_input_10

#include "gbs_types.h"

BANKREF_EXTERN(script_input_10)
extern const unsigned char script_input_10[];

#endif
