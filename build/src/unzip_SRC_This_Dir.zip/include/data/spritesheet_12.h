#ifndef SPRITESHEET_12_H
#define SPRITESHEET_12_H

// SpriteSheet: 12

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_12)
extern const struct spritesheet_t spritesheet_12;

#endif
