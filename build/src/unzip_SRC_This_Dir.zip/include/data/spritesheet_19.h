#ifndef SPRITESHEET_19_H
#define SPRITESHEET_19_H

// SpriteSheet: 19

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_19)
extern const struct spritesheet_t spritesheet_19;

#endif
