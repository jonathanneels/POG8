#ifndef TILESET_5_H
#define TILESET_5_H

// Tileset: 5

#include "gbs_types.h"

BANKREF_EXTERN(tileset_5)
extern const struct tileset_t tileset_5;

#endif
