#ifndef SPRITESHEET_7_H
#define SPRITESHEET_7_H

// SpriteSheet: 7

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_7)
extern const struct spritesheet_t spritesheet_7;

#endif
