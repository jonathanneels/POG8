#ifndef SPRITESHEET_4_H
#define SPRITESHEET_4_H

// SpriteSheet: 4

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_4)
extern const struct spritesheet_t spritesheet_4;

#endif
