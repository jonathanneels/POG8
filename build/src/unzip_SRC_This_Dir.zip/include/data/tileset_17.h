#ifndef TILESET_17_H
#define TILESET_17_H

// Tileset: 17

#include "gbs_types.h"

BANKREF_EXTERN(tileset_17)
extern const struct tileset_t tileset_17;

#endif
