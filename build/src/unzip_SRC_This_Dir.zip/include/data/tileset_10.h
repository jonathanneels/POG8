#ifndef TILESET_10_H
#define TILESET_10_H

// Tileset: 10

#include "gbs_types.h"

BANKREF_EXTERN(tileset_10)
extern const struct tileset_t tileset_10;

#endif
