#ifndef SCRIPT_INPUT_3_H
#define SCRIPT_INPUT_3_H

// Script script_input_3

#include "gbs_types.h"

BANKREF_EXTERN(script_input_3)
extern const unsigned char script_input_3[];

#endif
