#ifndef TILESET_18_H
#define TILESET_18_H

// Tileset: 18

#include "gbs_types.h"

BANKREF_EXTERN(tileset_18)
extern const struct tileset_t tileset_18;

#endif
