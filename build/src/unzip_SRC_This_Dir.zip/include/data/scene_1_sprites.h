#ifndef SCENE_1_SPRITES_H
#define SCENE_1_SPRITES_H

// Scene: sceneTBC
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_1_sprites)
extern const far_ptr_t scene_1_sprites[];

#endif
