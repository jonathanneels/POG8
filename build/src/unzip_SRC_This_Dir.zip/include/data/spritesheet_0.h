#ifndef SPRITESHEET_0_H
#define SPRITESHEET_0_H

// SpriteSheet: 0

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_0)
extern const struct spritesheet_t spritesheet_0;

#endif
