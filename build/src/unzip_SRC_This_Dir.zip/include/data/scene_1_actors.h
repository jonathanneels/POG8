#ifndef SCENE_1_ACTORS_H
#define SCENE_1_ACTORS_H

// Scene: sceneTBC
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_1_actors)
extern const struct actor_t scene_1_actors[];

#endif
