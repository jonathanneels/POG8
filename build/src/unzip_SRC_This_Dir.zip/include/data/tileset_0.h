#ifndef TILESET_0_H
#define TILESET_0_H

// Tileset: 0

#include "gbs_types.h"

BANKREF_EXTERN(tileset_0)
extern const struct tileset_t tileset_0;

#endif
