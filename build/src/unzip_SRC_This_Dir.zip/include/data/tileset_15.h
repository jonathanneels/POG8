#ifndef TILESET_15_H
#define TILESET_15_H

// Tileset: 15

#include "gbs_types.h"

BANKREF_EXTERN(tileset_15)
extern const struct tileset_t tileset_15;

#endif
