#ifndef SCRIPT_S3_INIT_H
#define SCRIPT_S3_INIT_H

// Script script_s3_init

#include "gbs_types.h"

BANKREF_EXTERN(script_s3_init)
extern const unsigned char script_s3_init[];

#endif
