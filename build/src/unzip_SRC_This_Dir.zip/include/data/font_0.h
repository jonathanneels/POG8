#ifndef FONT_0_H
#define FONT_0_H

// Font

#include "gbs_types.h"

BANKREF_EXTERN(font_0)
extern const unsigned char font_0[];

#endif
