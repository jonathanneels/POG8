#ifndef TILESET_9_H
#define TILESET_9_H

// Tileset: 9

#include "gbs_types.h"

BANKREF_EXTERN(tileset_9)
extern const struct tileset_t tileset_9;

#endif
