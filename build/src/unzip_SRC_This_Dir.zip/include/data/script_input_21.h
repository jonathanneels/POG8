#ifndef SCRIPT_INPUT_21_H
#define SCRIPT_INPUT_21_H

// Script script_input_21

#include "gbs_types.h"

BANKREF_EXTERN(script_input_21)
extern const unsigned char script_input_21[];

#endif
