#ifndef SPRITESHEET_17_H
#define SPRITESHEET_17_H

// SpriteSheet: 17

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_17)
extern const struct spritesheet_t spritesheet_17;

#endif
