#ifndef SPRITESHEET_5_H
#define SPRITESHEET_5_H

// SpriteSheet: 5

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_5)
extern const struct spritesheet_t spritesheet_5;

#endif
