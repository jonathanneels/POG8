#ifndef SPRITESHEET_15_H
#define SPRITESHEET_15_H

// SpriteSheet: 15

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_15)
extern const struct spritesheet_t spritesheet_15;

#endif
