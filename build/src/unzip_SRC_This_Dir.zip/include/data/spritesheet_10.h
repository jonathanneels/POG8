#ifndef SPRITESHEET_10_H
#define SPRITESHEET_10_H

// SpriteSheet: 10

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_10)
extern const struct spritesheet_t spritesheet_10;

#endif
