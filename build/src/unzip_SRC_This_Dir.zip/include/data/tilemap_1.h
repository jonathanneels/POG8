#ifndef TILEMAP_1_H
#define TILEMAP_1_H

// Tilemap 1

#include "gbs_types.h"

BANKREF_EXTERN(tilemap_1)
extern const unsigned char tilemap_1[];

#endif
