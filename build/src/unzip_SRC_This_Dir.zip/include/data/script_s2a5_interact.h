#ifndef SCRIPT_S2A5_INTERACT_H
#define SCRIPT_S2A5_INTERACT_H

// Script script_s2a5_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s2a5_interact)
extern const unsigned char script_s2a5_interact[];

#endif
