#ifndef BACKGROUND_0_H
#define BACKGROUND_0_H

// Background: 0

#include "gbs_types.h"

BANKREF_EXTERN(background_0)
extern const struct background_t background_0;

#endif
