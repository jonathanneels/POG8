#ifndef SCENE_1_COLLISIONS_H
#define SCENE_1_COLLISIONS_H

// Scene: sceneTBC
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_1_collisions)
extern const unsigned char scene_1_collisions[];

#endif
