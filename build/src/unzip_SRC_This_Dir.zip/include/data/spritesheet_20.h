#ifndef SPRITESHEET_20_H
#define SPRITESHEET_20_H

// SpriteSheet: 20

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_20)
extern const struct spritesheet_t spritesheet_20;

#endif
