#ifndef SCRIPT_S2_INIT_H
#define SCRIPT_S2_INIT_H

// Script script_s2_init

#include "gbs_types.h"

BANKREF_EXTERN(script_s2_init)
extern const unsigned char script_s2_init[];

#endif
