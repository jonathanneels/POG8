#ifndef SCRIPT_INPUT_17_H
#define SCRIPT_INPUT_17_H

// Script script_input_17

#include "gbs_types.h"

BANKREF_EXTERN(script_input_17)
extern const unsigned char script_input_17[];

#endif
