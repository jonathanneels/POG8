#ifndef SCRIPT_INPUT_20_H
#define SCRIPT_INPUT_20_H

// Script script_input_20

#include "gbs_types.h"

BANKREF_EXTERN(script_input_20)
extern const unsigned char script_input_20[];

#endif
