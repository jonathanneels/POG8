#ifndef SCENE_0_SPRITES_H
#define SCENE_0_SPRITES_H

// Scene: sceneInteraction
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_0_sprites)
extern const far_ptr_t scene_0_sprites[];

#endif
