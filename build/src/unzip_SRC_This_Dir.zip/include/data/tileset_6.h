#ifndef TILESET_6_H
#define TILESET_6_H

// Tileset: 6

#include "gbs_types.h"

BANKREF_EXTERN(tileset_6)
extern const struct tileset_t tileset_6;

#endif
