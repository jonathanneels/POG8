#ifndef SCENE_3_H
#define SCENE_3_H

// Scene: sceneStartA

#include "gbs_types.h"

BANKREF_EXTERN(scene_3)
extern const struct scene_t scene_3;

#endif
