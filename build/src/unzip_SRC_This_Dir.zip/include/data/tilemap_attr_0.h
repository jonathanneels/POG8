#ifndef TILEMAP_ATTR_0_H
#define TILEMAP_ATTR_0_H

// Tilemap Attr 0

#include "gbs_types.h"

BANKREF_EXTERN(tilemap_attr_0)
extern const unsigned char tilemap_attr_0[];

#endif
