#ifndef SCRIPT_INPUT_18_H
#define SCRIPT_INPUT_18_H

// Script script_input_18

#include "gbs_types.h"

BANKREF_EXTERN(script_input_18)
extern const unsigned char script_input_18[];

#endif
