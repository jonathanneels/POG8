#ifndef CURSOR_IMAGE_H
#define CURSOR_IMAGE_H

// Cursor

#include "gbs_types.h"

BANKREF_EXTERN(cursor_image)
extern const unsigned char cursor_image[];

#endif
