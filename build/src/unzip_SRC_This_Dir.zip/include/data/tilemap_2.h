#ifndef TILEMAP_2_H
#define TILEMAP_2_H

// Tilemap 2

#include "gbs_types.h"

BANKREF_EXTERN(tilemap_2)
extern const unsigned char tilemap_2[];

#endif
