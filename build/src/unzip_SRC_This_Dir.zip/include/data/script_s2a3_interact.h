#ifndef SCRIPT_S2A3_INTERACT_H
#define SCRIPT_S2A3_INTERACT_H

// Script script_s2a3_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s2a3_interact)
extern const unsigned char script_s2a3_interact[];

#endif
