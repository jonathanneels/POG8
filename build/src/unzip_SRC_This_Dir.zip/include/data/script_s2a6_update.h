#ifndef SCRIPT_S2A6_UPDATE_H
#define SCRIPT_S2A6_UPDATE_H

// Script script_s2a6_update

#include "gbs_types.h"

BANKREF_EXTERN(script_s2a6_update)
extern const unsigned char script_s2a6_update[];

#endif
