#ifndef SCRIPT_S2A0_INTERACT_H
#define SCRIPT_S2A0_INTERACT_H

// Script script_s2a0_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s2a0_interact)
extern const unsigned char script_s2a0_interact[];

#endif
