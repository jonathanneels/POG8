#ifndef TILESET_19_H
#define TILESET_19_H

// Tileset: 19

#include "gbs_types.h"

BANKREF_EXTERN(tileset_19)
extern const struct tileset_t tileset_19;

#endif
