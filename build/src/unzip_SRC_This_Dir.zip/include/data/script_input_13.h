#ifndef SCRIPT_INPUT_13_H
#define SCRIPT_INPUT_13_H

// Script script_input_13

#include "gbs_types.h"

BANKREF_EXTERN(script_input_13)
extern const unsigned char script_input_13[];

#endif
