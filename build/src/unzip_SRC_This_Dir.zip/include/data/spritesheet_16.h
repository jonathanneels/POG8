#ifndef SPRITESHEET_16_H
#define SPRITESHEET_16_H

// SpriteSheet: 16

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_16)
extern const struct spritesheet_t spritesheet_16;

#endif
