#ifndef SCRIPT_S1_INIT_H
#define SCRIPT_S1_INIT_H

// Script script_s1_init

#include "gbs_types.h"

BANKREF_EXTERN(script_s1_init)
extern const unsigned char script_s1_init[];

#endif
