#ifndef SPRITESHEET_13_H
#define SPRITESHEET_13_H

// SpriteSheet: 13

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_13)
extern const struct spritesheet_t spritesheet_13;

#endif
