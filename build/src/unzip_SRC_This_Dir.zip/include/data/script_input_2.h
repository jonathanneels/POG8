#ifndef SCRIPT_INPUT_2_H
#define SCRIPT_INPUT_2_H

// Script script_input_2

#include "gbs_types.h"

BANKREF_EXTERN(script_input_2)
extern const unsigned char script_input_2[];

#endif
