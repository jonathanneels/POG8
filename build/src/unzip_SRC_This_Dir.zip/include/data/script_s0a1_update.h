#ifndef SCRIPT_S0A1_UPDATE_H
#define SCRIPT_S0A1_UPDATE_H

// Script script_s0a1_update

#include "gbs_types.h"

BANKREF_EXTERN(script_s0a1_update)
extern const unsigned char script_s0a1_update[];

#endif
