#ifndef SCRIPT_S0A1_INTERACT_H
#define SCRIPT_S0A1_INTERACT_H

// Script script_s0a1_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s0a1_interact)
extern const unsigned char script_s0a1_interact[];

#endif
