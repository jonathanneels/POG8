#ifndef SCENE_2_ACTORS_H
#define SCENE_2_ACTORS_H

// Scene: sceneSelection
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_2_actors)
extern const struct actor_t scene_2_actors[];

#endif
