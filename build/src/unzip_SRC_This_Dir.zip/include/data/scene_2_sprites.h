#ifndef SCENE_2_SPRITES_H
#define SCENE_2_SPRITES_H

// Scene: sceneSelection
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_2_sprites)
extern const far_ptr_t scene_2_sprites[];

#endif
