#ifndef SPRITESHEET_18_H
#define SPRITESHEET_18_H

// SpriteSheet: 18

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_18)
extern const struct spritesheet_t spritesheet_18;

#endif
