#ifndef TILEMAP_0_H
#define TILEMAP_0_H

// Tilemap 0

#include "gbs_types.h"

BANKREF_EXTERN(tilemap_0)
extern const unsigned char tilemap_0[];

#endif
