#ifndef PALETTE_1_H
#define PALETTE_1_H

// Palette: 1

#include "gbs_types.h"

BANKREF_EXTERN(palette_1)
extern const struct palette_t palette_1;

#endif
