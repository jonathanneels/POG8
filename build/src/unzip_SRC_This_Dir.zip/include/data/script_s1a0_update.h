#ifndef SCRIPT_S1A0_UPDATE_H
#define SCRIPT_S1A0_UPDATE_H

// Script script_s1a0_update

#include "gbs_types.h"

BANKREF_EXTERN(script_s1a0_update)
extern const unsigned char script_s1a0_update[];

#endif
