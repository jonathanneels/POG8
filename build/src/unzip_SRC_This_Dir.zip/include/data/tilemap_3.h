#ifndef TILEMAP_3_H
#define TILEMAP_3_H

// Tilemap 3

#include "gbs_types.h"

BANKREF_EXTERN(tilemap_3)
extern const unsigned char tilemap_3[];

#endif
