#ifndef SCENE_2_H
#define SCENE_2_H

// Scene: sceneSelection

#include "gbs_types.h"

BANKREF_EXTERN(scene_2)
extern const struct scene_t scene_2;

#endif
