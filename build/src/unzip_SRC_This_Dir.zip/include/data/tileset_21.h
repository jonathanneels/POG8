#ifndef TILESET_21_H
#define TILESET_21_H

// Tileset: 21

#include "gbs_types.h"

BANKREF_EXTERN(tileset_21)
extern const struct tileset_t tileset_21;

#endif
