#ifndef SPRITESHEET_6_H
#define SPRITESHEET_6_H

// SpriteSheet: 6

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_6)
extern const struct spritesheet_t spritesheet_6;

#endif
