#ifndef SCRIPT_S0_INIT_H
#define SCRIPT_S0_INIT_H

// Script script_s0_init

#include "gbs_types.h"

BANKREF_EXTERN(script_s0_init)
extern const unsigned char script_s0_init[];

#endif
