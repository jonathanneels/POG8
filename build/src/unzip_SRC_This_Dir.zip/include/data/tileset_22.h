#ifndef TILESET_22_H
#define TILESET_22_H

// Tileset: 22

#include "gbs_types.h"

BANKREF_EXTERN(tileset_22)
extern const struct tileset_t tileset_22;

#endif
