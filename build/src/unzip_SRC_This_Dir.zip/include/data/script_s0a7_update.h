#ifndef SCRIPT_S0A7_UPDATE_H
#define SCRIPT_S0A7_UPDATE_H

// Script script_s0a7_update

#include "gbs_types.h"

BANKREF_EXTERN(script_s0a7_update)
extern const unsigned char script_s0a7_update[];

#endif
