#ifndef TILESET_3_H
#define TILESET_3_H

// Tileset: 3

#include "gbs_types.h"

BANKREF_EXTERN(tileset_3)
extern const struct tileset_t tileset_3;

#endif
