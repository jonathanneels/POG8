#ifndef TILESET_7_H
#define TILESET_7_H

// Tileset: 7

#include "gbs_types.h"

BANKREF_EXTERN(tileset_7)
extern const struct tileset_t tileset_7;

#endif
