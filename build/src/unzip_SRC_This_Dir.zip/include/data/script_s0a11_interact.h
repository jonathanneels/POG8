#ifndef SCRIPT_S0A11_INTERACT_H
#define SCRIPT_S0A11_INTERACT_H

// Script script_s0a11_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s0a11_interact)
extern const unsigned char script_s0a11_interact[];

#endif
