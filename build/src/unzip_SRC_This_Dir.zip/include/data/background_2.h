#ifndef BACKGROUND_2_H
#define BACKGROUND_2_H

// Background: 2

#include "gbs_types.h"

BANKREF_EXTERN(background_2)
extern const struct background_t background_2;

#endif
