#ifndef TILESET_12_H
#define TILESET_12_H

// Tileset: 12

#include "gbs_types.h"

BANKREF_EXTERN(tileset_12)
extern const struct tileset_t tileset_12;

#endif
