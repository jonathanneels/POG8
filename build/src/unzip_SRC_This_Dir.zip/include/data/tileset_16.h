#ifndef TILESET_16_H
#define TILESET_16_H

// Tileset: 16

#include "gbs_types.h"

BANKREF_EXTERN(tileset_16)
extern const struct tileset_t tileset_16;

#endif
