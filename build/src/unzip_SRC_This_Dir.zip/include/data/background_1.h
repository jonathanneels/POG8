#ifndef BACKGROUND_1_H
#define BACKGROUND_1_H

// Background: 1

#include "gbs_types.h"

BANKREF_EXTERN(background_1)
extern const struct background_t background_1;

#endif
