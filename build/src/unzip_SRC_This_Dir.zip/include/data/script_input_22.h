#ifndef SCRIPT_INPUT_22_H
#define SCRIPT_INPUT_22_H

// Script script_input_22

#include "gbs_types.h"

BANKREF_EXTERN(script_input_22)
extern const unsigned char script_input_22[];

#endif
