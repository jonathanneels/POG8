#ifndef TILESET_2_H
#define TILESET_2_H

// Tileset: 2

#include "gbs_types.h"

BANKREF_EXTERN(tileset_2)
extern const struct tileset_t tileset_2;

#endif
