#ifndef SCRIPT_S0A12_INTERACT_H
#define SCRIPT_S0A12_INTERACT_H

// Script script_s0a12_interact

#include "gbs_types.h"

BANKREF_EXTERN(script_s0a12_interact)
extern const unsigned char script_s0a12_interact[];

#endif
