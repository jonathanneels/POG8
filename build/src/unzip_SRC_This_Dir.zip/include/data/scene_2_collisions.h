#ifndef SCENE_2_COLLISIONS_H
#define SCENE_2_COLLISIONS_H

// Scene: sceneSelection
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_2_collisions)
extern const unsigned char scene_2_collisions[];

#endif
