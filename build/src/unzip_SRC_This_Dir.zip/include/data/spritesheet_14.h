#ifndef SPRITESHEET_14_H
#define SPRITESHEET_14_H

// SpriteSheet: 14

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_14)
extern const struct spritesheet_t spritesheet_14;

#endif
