#ifndef SPRITESHEET_2_H
#define SPRITESHEET_2_H

// SpriteSheet: 2

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_2)
extern const struct spritesheet_t spritesheet_2;

#endif
