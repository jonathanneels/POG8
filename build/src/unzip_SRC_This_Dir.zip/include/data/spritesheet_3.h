#ifndef SPRITESHEET_3_H
#define SPRITESHEET_3_H

// SpriteSheet: 3

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_3)
extern const struct spritesheet_t spritesheet_3;

#endif
