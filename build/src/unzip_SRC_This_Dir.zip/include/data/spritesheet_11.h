#ifndef SPRITESHEET_11_H
#define SPRITESHEET_11_H

// SpriteSheet: 11

#include "gbs_types.h"

BANKREF_EXTERN(spritesheet_11)
extern const struct spritesheet_t spritesheet_11;

#endif
