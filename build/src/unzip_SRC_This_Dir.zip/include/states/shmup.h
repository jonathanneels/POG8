#ifndef STATE_SHMUP_H
#define STATE_SHMUP_H

#include <gb/gb.h>

void shmup_init();
void shmup_update();

#endif
