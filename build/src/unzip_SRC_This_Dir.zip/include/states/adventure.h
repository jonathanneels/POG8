#ifndef STATE_ADVENTURE_H
#define STATE_ADVENTURE_H

#include <gb/gb.h>

void adventure_init();
void adventure_update();

#endif
