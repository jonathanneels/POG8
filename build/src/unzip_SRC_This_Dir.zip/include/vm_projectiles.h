#ifndef _VM_PROJECTILES_H_INCLUDE
#define _VM_PROJECTILES_H_INCLUDE

#include "vm.h"
#include "gbs_types.h"

void vm_projectile_launch(SCRIPT_CTX * THIS, UBYTE type, INT16 idx) OLDCALL BANKED;

#endif