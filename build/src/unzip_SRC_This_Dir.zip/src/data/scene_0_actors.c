#pragma bank 255

// Scene: sceneInteraction
// Actors

#include "gbs_types.h"
#include "data/spritesheet_2.h"
#include "data/script_s0a0_update.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a1_update.h"
#include "data/script_s0a1_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a2_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a3_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a4_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a5_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a6_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a7_update.h"
#include "data/script_s0a7_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a8_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a9_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a10_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a11_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a12_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a13_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a14_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a15_interact.h"
#include "data/spritesheet_1.h"
#include "data/script_s0a16_interact.h"
#include "data/spritesheet_2.h"
#include "data/spritesheet_2.h"

BANKREF(scene_0_actors)

const struct actor_t scene_0_actors[] = {
    {
        // actorSound0,
        .pos = {
            .x = 24 * 16,
            .y = 0 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_UP,
        .sprite = TO_FAR_PTR_T(spritesheet_2),
        .move_speed = 16,
        .anim_tick = 127,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(script_s0a0_update),
        .reserve_tiles = 0
    },
    {
        // actorBlockL0,
        .pos = {
            .x = 24 * 16,
            .y = 16 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(script_s0a1_update),
        .script = TO_FAR_PTR_T(script_s0a1_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL14,
        .pos = {
            .x = 56 * 16,
            .y = 112 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 8,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a2_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL4,
        .pos = {
            .x = 120 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a3_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL15,
        .pos = {
            .x = 24 * 16,
            .y = 112 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a4_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL12,
        .pos = {
            .x = 120 * 16,
            .y = 112 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a5_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL13,
        .pos = {
            .x = 88 * 16,
            .y = 112 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a6_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockR8,
        .pos = {
            .x = 24 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(script_s0a7_update),
        .script = TO_FAR_PTR_T(script_s0a7_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL9,
        .pos = {
            .x = 56 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a8_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL10,
        .pos = {
            .x = 88 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a9_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL1,
        .pos = {
            .x = 56 * 16,
            .y = 16 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a10_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL2,
        .pos = {
            .x = 88 * 16,
            .y = 16 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a11_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL3,
        .pos = {
            .x = 120 * 16,
            .y = 16 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a12_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL7,
        .pos = {
            .x = 24 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a13_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL11,
        .pos = {
            .x = 120 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a14_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL6,
        .pos = {
            .x = 56 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a15_interact),
        .reserve_tiles = 4
    },
    {
        // actorBlockL5,
        .pos = {
            .x = 88 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_1),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(script_s0a16_interact),
        .reserve_tiles = 4
    },
    {
        // aStarRate,
        .pos = {
            .x = 80 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_2),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 4
    },
    {
        // aNoteInfo,
        .pos = {
            .x = 64 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(spritesheet_2),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 4
    }
};
