#pragma bank 255

// Tileset: 4

#include "gbs_types.h"

BANKREF(tileset_4)

const struct tileset_t tileset_4 = {
    .n_tiles = 0,
    .tiles = {
        0x00
    }
};
