﻿using CefSharp.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pog8_Local
{
    public partial class Form1 : Form
    {
        public static int port = 8919;
        HTTPServer myServer;
        public Form1()
        {
            InitializeComponent(); 


            myServer = new  HTTPServer( HTTPServer.serverpath, port);


            string path = System.AppDomain.CurrentDomain.BaseDirectory + "files\\";


            try
            {
                CefSettings settings = new CefSettings();
                settings.CachePath = path;
                settings.CefCommandLineArgs.Add("enable-experimental-web-platform-features", "1"); 
                CefSharp.Cef.Initialize(settings);

            }
            catch (Exception ex)
            {
                MessageBox.Show(  ex.InnerException.ToString());


            }

            if (Directory.Exists(path))
            {

                DirectoryCalculator.AllFiles = System.IO.Directory.GetFiles(path, "*.*", System.IO.SearchOption.AllDirectories);
                DirectoryCalculator.dirName = new DirectoryInfo(path).Name;
                HTTPServer.serverpath = path; // standaardlocatie is de map van executie.


                chromiumWebBrowser1.LoadUrl("http://127.0.0.1:" +port.ToString()+ "/index.html"); //path + "index.html");
            }


        //    


        }


        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button.ToString().ToLower() == "right")
            {
                return;
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            myServer.Stop();

        }
    }
}
