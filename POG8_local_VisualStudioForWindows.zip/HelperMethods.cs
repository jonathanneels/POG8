﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pog8_Local
{
    public class HelperMethods
    {
        //protected void OnBtnShareDocsClicked(object sender, EventArgs e) //https://stackoverflow.com/questions/12436186/how-to-start-exe-file-contained-in-my-project-in-c
        //{
        //    Process.Start("JoSimpleHTTPServer.exe");

        //}

        public static void KillProcessOnWindows(string processname)//https://www.codeproject.com/Questions/794195/Close-the-all-browser-windows-IE-google-chrome-fir & https://social.msdn.microsoft.com/Forums/en-US/fd48f01f-e373-4925-af86-4006f8ca7600/how-to-close-all-browser-using-c?forum=csharplanguage
        {
            Process[] localByName = Process.GetProcessesByName(processname);

            foreach (Process item in localByName)
            {
                item.Kill();
            }

        }
         
    }
}
