﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pog8_Local
{
    public class DirectoryCalculator
    {
        public static string[] AllFiles = new string[] { };
        public static string dirName = "";
        public static string allinfo = "HIDDEN";

    }
}
